from utils.db import get_db


class User:
    def __init__(self, row):
        self.id = row['id']
        self.full_name = row['full_name']
        self.email = row['email']
        self.phone = row['phone']
        self.password_hash = row['password_hash']
        self.role = row['role']
        self.balance = row['balance']
        self.is_active = row['is_active']
        self.created_at = row['created_at']

    @staticmethod
    def get_by_id(user_id):
        db = get_db()
        row = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        return User(row) if row else None

    @staticmethod
    def get_by_email(email):
        db = get_db()
        row = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        return User(row) if row else None

    @staticmethod
    def get_by_phone(phone):
        db = get_db()
        row = db.execute('SELECT * FROM users WHERE phone = ?', (phone,)).fetchone()
        return User(row) if row else None

    @staticmethod
    def get_by_reset_token(token):
        db = get_db()
        row = db.execute('SELECT * FROM users WHERE reset_token = ?', (token,)).fetchone()
        return User(row) if row else None

    @staticmethod
    def get_all():
        db = get_db()
        rows = db.execute('SELECT * FROM users ORDER BY created_at DESC').fetchall()
        return [User(r) for r in rows]

    @staticmethod
    def count():
        db = get_db()
        return db.execute('SELECT COUNT(*) FROM users').fetchone()[0]

    def to_dict(self):
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'phone': self.phone,
            'role': self.role,
            'balance': self.balance,
            'is_active': self.is_active,
            'created_at': self.created_at
        }
