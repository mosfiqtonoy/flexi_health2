from utils.db import get_db
from models.user import User


def get_user_profile(user_id):
    return User.get_by_id(user_id)


def update_user_profile(user_id, full_name, phone):
    db = get_db()
    existing = db.execute(
        'SELECT id FROM users WHERE phone = ? AND id != ?', (phone, user_id)
    ).fetchone()
    if existing:
        return False, 'Phone number already in use.'
    db.execute(
        'UPDATE users SET full_name = ?, phone = ? WHERE id = ?',
        (full_name.strip(), phone.strip(), user_id)
    )
    db.commit()
    return True, 'Profile updated.'


def add_recharge(user_id, amount, operator):
    save_pct = 0.10
    saved = round(amount * save_pct, 2)
    db = get_db()
    db.execute(
        'INSERT INTO recharge_history (user_id, amount, saved_amount, operator) VALUES (?, ?, ?, ?)',
        (user_id, amount, saved, operator)
    )
    db.execute(
        'UPDATE users SET balance = balance + ? WHERE id = ?',
        (saved, user_id)
    )
    db.commit()
    return saved


def get_recharge_history(user_id):
    db = get_db()
    rows = db.execute(
        'SELECT * FROM recharge_history WHERE user_id = ? ORDER BY created_at DESC',
        (user_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def get_all_users():
    return User.get_all()


def toggle_user_status(user_id):
    db = get_db()
    user = User.get_by_id(user_id)
    if not user:
        return False, 'User not found.'
    new_status = 0 if user.is_active else 1
    db.execute('UPDATE users SET is_active = ? WHERE id = ?', (new_status, user_id))
    db.commit()
    return True, 'Status updated.'
