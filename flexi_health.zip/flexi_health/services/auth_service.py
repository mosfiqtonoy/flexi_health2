import time
from utils.db import get_db
from utils.security import hash_password, check_password, generate_token, token_expiry
from models.user import User


def register_user(full_name, email, phone, password):
    db = get_db()
    if User.get_by_email(email):
        return False, 'Email already registered.'
    if User.get_by_phone(phone):
        return False, 'Phone number already registered.'
    pw_hash = hash_password(password)
    db.execute(
        'INSERT INTO users (full_name, email, phone, password_hash) VALUES (?, ?, ?, ?)',
        (full_name.strip(), email.strip().lower(), phone.strip(), pw_hash)
    )
    db.commit()
    return True, 'Registration successful.'


def authenticate_user(email_or_phone, password):
    user = User.get_by_email(email_or_phone.strip().lower())
    if not user:
        user = User.get_by_phone(email_or_phone.strip())
    if not user:
        return None, 'Invalid credentials.'
    if not user.is_active:
        return None, 'Account is deactivated.'
    if not check_password(password, user.password_hash):
        return None, 'Invalid credentials.'
    return user, 'Login successful.'


def initiate_password_reset(email):
    user = User.get_by_email(email.strip().lower())
    if not user:
        return False, 'No account found with that email.'
    token = generate_token()
    expiry = token_expiry(60)
    db = get_db()
    db.execute(
        'UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?',
        (token, expiry, user.id)
    )
    db.commit()
    return True, token


def reset_password(token, new_password):
    user = User.get_by_reset_token(token)
    if not user:
        return False, 'Invalid or expired reset link.'
    db = get_db()
    row = db.execute('SELECT reset_token_expiry FROM users WHERE id = ?', (user.id,)).fetchone()
    if not row or int(time.time()) > row['reset_token_expiry']:
        return False, 'Reset link has expired.'
    pw_hash = hash_password(new_password)
    db.execute(
        'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?',
        (pw_hash, user.id)
    )
    db.commit()
    return True, 'Password reset successful.'
