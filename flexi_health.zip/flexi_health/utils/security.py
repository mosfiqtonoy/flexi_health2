import hashlib
import hmac
import secrets
import time
from functools import wraps
from flask import session, redirect, url_for, jsonify, request


def hash_password(password: str) -> str:
    import hashlib, os, binascii
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 260000)
    return f"pbkdf2:sha256:260000${binascii.hexlify(salt).decode()}${binascii.hexlify(dk).decode()}"


def check_password(password: str, password_hash: str) -> bool:
    import hashlib, binascii
    try:
        parts = password_hash.split('$')
        if len(parts) != 3:
            return False
        algo_info, salt_hex, dk_hex = parts
        salt = binascii.unhexlify(salt_hex)
        iterations = int(algo_info.split(':')[2])
        dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, iterations)
        return hmac.compare_digest(binascii.hexlify(dk).decode(), dk_hex)
    except Exception:
        return False


def generate_token(length: int = 32) -> str:
    return secrets.token_urlsafe(length)


def token_expiry(minutes: int = 60) -> int:
    return int(time.time()) + (minutes * 60)


def is_token_valid(expiry: int) -> bool:
    return int(time.time()) < expiry


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        if session.get('role') != 'admin':
            return redirect(url_for('errors.forbidden'))
        return f(*args, **kwargs)
    return decorated


def api_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated


def api_admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Authentication required'}), 401
        if session.get('role') != 'admin':
            return jsonify({'success': False, 'message': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated
